/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_162()
{
    return 3284638024U;
}

unsigned addval_493(unsigned x)
{
    return x + 3284633928U;
}

void setval_235(unsigned *p)
{
    *p = 2438520153U;
}

unsigned getval_447()
{
    return 1841533016U;
}

void setval_264(unsigned *p)
{
    *p = 3351742792U;
}

void setval_153(unsigned *p)
{
    *p = 2488855718U;
}

unsigned addval_420(unsigned x)
{
    return x + 3281031256U;
}

unsigned addval_193(unsigned x)
{
    return x + 2428995912U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_434()
{
    return 3523267209U;
}

void setval_489(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_275()
{
    return 2646854281U;
}

unsigned addval_204(unsigned x)
{
    return x + 3380139657U;
}

void setval_303(unsigned *p)
{
    *p = 3221801609U;
}

unsigned getval_274()
{
    return 3286276424U;
}

void setval_310(unsigned *p)
{
    *p = 3675832713U;
}

unsigned addval_416(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_176()
{
    return 3286272328U;
}

unsigned getval_213()
{
    return 3285584360U;
}

unsigned getval_195()
{
    return 3374367112U;
}

unsigned addval_233(unsigned x)
{
    return x + 3224947401U;
}

unsigned addval_203(unsigned x)
{
    return x + 3281308297U;
}

void setval_110(unsigned *p)
{
    *p = 3229928077U;
}

unsigned getval_161()
{
    return 3676359369U;
}

unsigned getval_202()
{
    return 3525362057U;
}

void setval_280(unsigned *p)
{
    *p = 3525886345U;
}

unsigned getval_365()
{
    return 3286272329U;
}

void setval_312(unsigned *p)
{
    *p = 3252717896U;
}

unsigned addval_289(unsigned x)
{
    return x + 3680556681U;
}

void setval_296(unsigned *p)
{
    *p = 3223372161U;
}

unsigned getval_341()
{
    return 3372799625U;
}

void setval_411(unsigned *p)
{
    *p = 3523789193U;
}

unsigned getval_488()
{
    return 3683959177U;
}

unsigned getval_409()
{
    return 3523789257U;
}

void setval_361(unsigned *p)
{
    *p = 3247491721U;
}

void setval_433(unsigned *p)
{
    *p = 3224950409U;
}

void setval_117(unsigned *p)
{
    *p = 3285633521U;
}

unsigned addval_371(unsigned x)
{
    return x + 3286272328U;
}

void setval_346(unsigned *p)
{
    *p = 3375421065U;
}

unsigned getval_160()
{
    return 2425542281U;
}

void setval_230(unsigned *p)
{
    *p = 2464188744U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
